package homework;

import java.util.*;


public class ListOperations {
    public static void main(String[] args) {

        List<Integer> intList = new ArrayList<>();

        intList.add(3);
        intList.add(4);
        intList.add(7);
        intList.add(9);
        intList.add(2);
        intList.add(4);
        intList.add(1);

        System.out.println(multiplyBy22(intList));

        List<String> str = Arrays.asList("ghg", "dwr", "fsdf");
        System.out.println(str);
        List<Integer> sizeList = getLengthsOfList(str);
        System.out.println(sizeList);

        List<Integer> oddNumbers = getListOfOddNumbers(intList);
        System.out.println(oddNumbers);

        List<String> str1 = Arrays.asList("hi", "summer", "autumn", "hi");
        Set<String> set = new LinkedHashSet<>(str1);

        List<String> newList = new ArrayList<>(set);
        System.out.println(newList);

    }

    // 1.у вас есть список значений int и вы должны вернуть список, каждое значение которого умножается на 22.

    public static List<Integer> multiplyBy22(List<Integer> list) {
        List<Integer> result = new ArrayList<>();
        for (int num : list) {
            result.add(num * 22);
        }
        return result;
    }

    // 2.у вас есть список значений String , и вы должны вернуть список длины каждого из этих значений String .
    public static List<Integer> getLengthsOfList(List<String> strings) {
        List<Integer> result = new ArrayList<>();
        for (String str : strings) {
            result.add(str.length());
        }
        return result;
    }


    // 3.у вас есть список значений int и вы должны вернуть список, содержащий только нечетные числа
    public static List<Integer> getListOfOddNumbers(List<Integer> numbers) {
        List<Integer> result = new ArrayList<>();
        for (int num : numbers) {
            if (num % 2 != 0) {
                result.add(num);
            }
        }
        return result;
    }
}

    // 4.у вас есть список значений String , и вы должны вернуть список этих значений без каких-либо дубликатов.












/*
 1 уровень сложности: Немного домашки на списки :
1.у вас есть список значений int и вы должны вернуть список, каждое значение которого умножается на 22.
2.у вас есть список значений String , и вы должны вернуть список длины каждого из этих значений String .
3.у вас есть список значений int и вы должны вернуть список, содержащий только нечетные числа
4.у вас есть список значений String , и вы должны вернуть список этих значений без каких-либо дубликатов.
 */